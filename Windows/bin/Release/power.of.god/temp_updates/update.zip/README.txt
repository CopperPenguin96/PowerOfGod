-----Power of God-----
=======================
What Is This?
-------------

This java application is dedicated to help me study the holy scripture
more and to help you learn more about our Lord and Savior Jesus Christ.
If you do not know Christ as your Savior, please consider looking into
this.


What is Included Here
---------------------

* Power_of_God.jar - The executable
* \lib - The directory in which all the program libraries are
* \lib\json-simple-1.1.1.jar - What we use to save your user information
* \lib\NetBible.jar - Library for retrieving Bible verses
* \lib\TitleExtractor.jar - Reads webpage titles


How To Run (Windows)
--------------------

1. Have installed the appropiate java version (Java 8 Any version)
2. Drag-and-drop all provided files into desired folder (Do not remove anything or the program will not work)
3. Double click Power_of_God.jar to run, or run in command line java -jar Power_of_God.jar

How To Run (Mac/Linux)
----------------------

1. Have installed the appropiate java version (Java 8 Any version)
2. Drag-and-drop all provided files into desired folder (Do not remove anything or the program will not work)
3. In terminal, run java -jar Power_of_God.jar
(If there are any issues in the mac/linux steps, please report)