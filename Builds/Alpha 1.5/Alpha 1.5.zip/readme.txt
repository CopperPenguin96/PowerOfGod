Power of God Readme File
-=-=-=-=-=-=-=-=-=-=-=-=

Requirements
-=-=-=-=-=-=

Windows
-------
Net Framework 4.5

Linux/Max
-------
Mono Runtime 3.10.0+
libgluezilla
